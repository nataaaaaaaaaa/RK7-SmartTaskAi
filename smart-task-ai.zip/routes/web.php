<?php

use App\Http\Controllers\TaskController;
use App\Http\Controllers\ProfileController; // Tambahkan ini
use Illuminate\Support\Facades\Route;

// Halaman utama langsung ke login/register
Route::get('/', function () {
    return redirect('/tasks');
});

Route::middleware(['auth'])->group(function () {
    // Rute Aplikasi SmartTask AI kita
    Route::get('/tasks', [TaskController::class, 'index'])->name('dashboard');
    Route::post('/tasks', [TaskController::class, 'store']);
    Route::patch('/tasks/{task}/complete', [TaskController::class, 'complete']);
    Route::delete('/tasks/{task}', [TaskController::class, 'destroy']);

    // Rute Profile (Wajib ada agar Breeze tidak error)
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
