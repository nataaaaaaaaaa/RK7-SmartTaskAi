<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = auth()->user()->tasks()->orderBy('priority', 'asc')->orderBy('deadline', 'asc')->get();

        $totalTasks = $tasks->count();
        $completedTasks = $tasks->where('is_completed', true)->count();
        $pendingTasks = $totalTasks - $completedTasks;
        $productivityScore = $totalTasks > 0 ? round(($completedTasks / $totalTasks) * 100) : 0;
        $avgEnergyDone = $tasks->where('is_completed', true)->avg('energy_level') ?? 0;
        $avgEnergyPending = $tasks->where('is_completed', false)->avg('energy_level') ?? 0;

        return view('tasks.index', compact('tasks', 'completedTasks', 'pendingTasks', 'productivityScore', 'avgEnergyDone', 'avgEnergyPending'));
    }

    public function store(Request $request)
    {
        $request->validate(['title' => 'required', 'deadline' => 'required']);

        auth()->user()->tasks()->create([
            'title' => $request->title,
            'priority' => $request->priority,
            'energy_level' => $request->energy_level,
            'deadline' => $request->deadline,
        ]);

        return redirect('/tasks');
    }

    public function complete(Task $task)
    {
        // Pastikan hanya pemilik yang bisa update
        if ($task->user_id !== auth()->id()) abort(403);

        $task->update(['is_completed' => true]);
        
        $currentXp = session('user_xp', 0);
        session(['user_xp' => $currentXp + 10]);

        return redirect('/tasks');
    }

    public function destroy(Task $task)
    {
        if ($task->user_id !== auth()->id()) abort(403);
        
        $task->delete();
        return redirect('/tasks');
    }
}