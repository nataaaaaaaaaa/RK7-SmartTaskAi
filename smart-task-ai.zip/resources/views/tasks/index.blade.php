<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartTask AI - Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-body: #0a0e17; --bg-card: #111827; --bg-input: #1f2937;
            --primary: #6366f1; --text-main: #f3f4f6; --text-muted: #9ca3af;
            --success: #10b981; --warning: #f59e0b; --danger: #ef4444; --border: #374151;
        }

        * { box-sizing: border-box; transition: all 0.2s ease-out; }
        body {
            font-family: 'Poppins', sans-serif; background-color: var(--bg-body);
            color: var(--text-main); margin: 0; padding: 30px; min-height: 100vh;
            background-image: radial-gradient(at 10% 10%, rgba(99, 102, 241, 0.15) 0px, transparent 50%);
        }
        .container { max-width: 1200px; margin: 0 auto; }

        /* --- Header & Profile --- */
        .user-header {
            display: flex; justify-content: space-between; align-items: center;
            background: var(--bg-card); padding: 20px 30px; border-radius: 20px;
            margin-bottom: 30px; border: 1px solid var(--border);
        }
        .user-profile { display: flex; align-items: center; gap: 15px; }
        .avatar {
            width: 45px; height: 45px; background: var(--primary);
            border-radius: 50%; display: flex; align-items: center;
            justify-content: center; font-weight: 800; color: white;
        }

        /* --- Stats & Gamification --- */
        .main-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 25px; margin-bottom: 30px; }
        .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .stat-card {
            background: var(--bg-card); padding: 20px; border-radius: 16px;
            border: 1px solid var(--border); text-align: center;
        }
        .score-card {
            background: var(--bg-card); padding: 20px; border-radius: 16px;
            border: 1px solid var(--border);
        }
        .progress-bar-bg { background: var(--bg-input); height: 10px; border-radius: 5px; margin: 10px 0; overflow: hidden; }
        .progress-fill { background: var(--primary); height: 100%; transition: width 1s; }

        /* --- Focus & AI Area --- */
        #focus-area {
            background: #0f172a; padding: 40px; border-radius: 24px; border: 2px solid var(--primary);
            text-align: center; margin-bottom: 30px; display: none;
        }
        #timer { font-size: 6rem; font-weight: 800; color: var(--primary); margin: 15px 0; font-family: monospace; }

        /* --- Action Area --- */
        .action-box { background: var(--bg-card); padding: 25px; border-radius: 20px; border: 1px solid var(--border); }
        .form-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 10px; margin-bottom: 25px; align-items: flex-end; }
        input, select {
            width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border);
            background: var(--bg-input); color: white;
        }
        
        /* --- Table --- */
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { text-align: left; padding: 12px; color: var(--text-muted); font-size: 0.8rem; border-bottom: 1px solid var(--border); }
        td { padding: 15px 12px; border-bottom: 1px solid rgba(55, 65, 81, 0.3); }
        .badge { padding: 4px 8px; border-radius: 5px; font-size: 0.7rem; font-weight: 700; }
        .btn { padding: 8px 15px; border-radius: 8px; border: none; cursor: pointer; font-weight: 600; font-size: 0.85rem; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-logout { background: transparent; color: var(--danger); border: 1px solid var(--danger); }
    </style>
</head>
<body>

<div class="container">
    
    <div class="user-header">
        <div>
            <h1 style="margin:0; font-size: 1.4rem;">Halo, {{ Auth::user()->name }}! 👋</h1>
            <p style="margin:5px 0 0 0; color: var(--text-muted); font-size: 0.85rem;">Siap produktif hari ini?</p>
        </div>
        <div class="user-profile">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn btn-logout">Logout</button>
            </form>
            <div class="avatar">{{ substr(Auth::user()->name, 0, 1) }}</div>
        </div>
    </div>

    <div class="main-grid">
        <div class="stats-grid">
            <div class="stat-card">
                <span style="color: var(--text-muted); font-size: 0.75rem;">SELESAI</span>
                <h2 style="margin:10px 0; color: var(--success);">{{ $completedTasks }}</h2>
            </div>
            <div class="stat-card">
                <span style="color: var(--text-muted); font-size: 0.75rem;">PENDING</span>
                <h2 style="margin:10px 0; color: var(--warning);">{{ $pendingTasks }}</h2>
            </div>
        </div>
        <div class="score-card">
            @php 
                $xp = session('user_xp', 0); 
                $level = floor($xp / 50) + 1; 
                $progress = ($xp % 50) * 2; 
            @endphp
            <div style="display: flex; justify-content: space-between;">
                <span style="font-weight: 700;">Lv. {{ $level }}</span>
                <span style="font-size: 0.8rem; color: var(--text-muted);">Produktivitas: {{ $productivityScore }}%</span>
            </div>
            <div class="progress-bar-bg"><div class="progress-fill" style="width: {{ $progress }}%;"></div></div>
            <span style="font-size: 0.7rem;">{{ $xp }} Total XP</span>
        </div>
    </div>

    <div style="background: rgba(99, 102, 241, 0.1); padding: 20px; border-radius: 15px; border-left: 5px solid var(--primary); margin-bottom: 30px;">
        <strong style="color: var(--primary);">🤖 AI Recommendation:</strong>
        @php $suggest = $tasks->where('is_completed', false)->first(); @endphp
        @if($suggest)
            Tugas <u>{{ $suggest->title }}</u> cocok dengan tingkat energi Anda saat ini. Mulailah sekarang!
        @else
            Belum ada rencana. Tambahkan tugas baru untuk memulai.
        @endif
    </div>

    <div id="focus-area">
        <h3 style="margin:0; color: var(--text-muted);">DEEP FOCUS MODE</h3>
        <h2 id="focus-task-name">Tugas...</h2>
        <div id="timer">25:00</div>
        <button onclick="stopFocus()" class="btn" style="background: rgba(239, 68, 68, 0.1); color: var(--danger);">Hentikan Sesi</button>
    </div>

    <div class="action-box">
        <h3 style="margin-top:0;">⚡ Tambah Tugas</h3>
        <form action="/tasks" method="POST" class="form-grid">
            @csrf
            <div><label style="font-size: 0.7rem;">JUDUL</label><input type="text" name="title" required></div>
            <div><label style="font-size: 0.7rem;">PRIORITAS</label><select name="priority"><option value="1">Tinggi</option><option value="2" selected>Sedang</option><option value="3">Rendah</option></select></div>
            <div><label style="font-size: 0.7rem;">ENERGI</label><select name="energy_level"><option value="1">⚡ 1</option><option value="3" selected>⚡ 3</option><option value="5">⚡ 5</option></select></div>
            <div><label style="font-size: 0.7rem;">DEADLINE</label><input type="datetime-local" name="deadline" required></div>
            <button type="submit" class="btn btn-primary" style="height: 40px;">Simpan</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Tugas</th>
                    <th>Prioritas</th>
                    <th>Energi</th>
                    <th>Deadline</th>
                    <th style="text-align: right;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($tasks as $task)
                <tr style="{{ $task->is_completed ? 'opacity: 0.4;' : '' }}">
                    <td><strong style="{{ $task->is_completed ? 'text-decoration: line-through;' : '' }}">{{ $task->title }}</strong></td>
                    <td>
                        <span class="badge" style="background: {{ $task->priority == 1 ? 'rgba(239,68,68,0.2); color: #f87171;' : 'rgba(245,158,11,0.2); color: #fbbf24;' }}">
                            {{ $task->priority == 1 ? 'HIGH' : 'MED' }}
                        </span>
                    </td>
                    <td>{{ $task->energy_level }}/5 ⚡</td>
                    <td>{{ date('d M, H:i', strtotime($task->deadline)) }}</td>
                    <td style="text-align: right; display: flex; gap: 5px; justify-content: flex-end;">
                        @if(!$task->is_completed)
                            <form action="/tasks/{{ $task->id }}/complete" method="POST">@csrf @method('PATCH')<button type="submit" class="btn" style="background: var(--success); color: white;">✓</button></form>
                            <button onclick="startFocus('{{ $task->title }}')" class="btn" style="background: var(--bg-input); color: white;">🎯</button>
                        @endif
                        <form action="/tasks/{{ $task->id }}" method="POST">@csrf @method('DELETE')<button type="submit" class="btn" style="color: var(--danger); background: none;">🗑️</button></form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

</div>

<script>
    let countdown;
    let timeLeft = 25 * 60;
    function startFocus(name) {
        document.getElementById('focus-area').style.display = 'block';
        document.getElementById('focus-task-name').innerText = name;
        window.scrollTo({top: 0, behavior: 'smooth'});
        timeLeft = 25 * 60;
        updateDisplay();
        clearInterval(countdown);
        countdown = setInterval(() => {
            timeLeft--; updateDisplay();
            if (timeLeft <= 0) { clearInterval(countdown); alert("Waktu fokus habis!"); stopFocus(); }
        }, 1000);
    }
    function stopFocus() { clearInterval(countdown); document.getElementById('focus-area').style.display = 'none'; }
    function updateDisplay() {
        let m = Math.floor(timeLeft / 60); let s = timeLeft % 60;
        document.getElementById('timer').innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
</script>

</body>
</html>